#pragma once

#include "ofMain.h"
#include "ofxOpenCv.h"
#include "ofxKinect.h"
#include "ofxBox2d.h"
class Particle: public ofxBox2dCircle {
public:
	void init() {
		if(flare==NULL) {
			flare = new ofImage();
			flare->loadImage("flare.png");
			flare->setAnchorPercent(0.5, 0.5);
		}
	}
	
	void draw() {
		flare->draw(getPosition());
	}
private:
	static ofImage *flare;
};

class testApp : public ofBaseApp{

public:
	void setup();
	void update();
	void draw();

	void keyPressed  (int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y );
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);
	
	void updateBox2d();
	void addParticle(float x, float y);
	ofxCvGrayscaleImage depth;
	ofxKinect kinect;
	ofxCvContourFinder contours;
	ofxBox2d box2d;
	
	vector<Particle> particles;
	vector<ofxBox2dPolygon> outlines;
	
	bool learnBackground;
	float nearThreshold;
	float farThreshold;
	int hysteresis;
	
};
