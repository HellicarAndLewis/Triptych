#include "testApp.h"

#include "ofxSimpleGuiToo.h"
ofImage *Particle::flare = NULL;
//--------------------------------------------------------------
void testApp::setup(){
	depth.allocate(640, 480);
	bgImg.allocate(VISION_HEIGHT, VISION_WIDTH);
	kinect.init();
	kinect.open();
	kinect.setRegistration(true);
	
	
	box2d.init();
	box2d.setGravity(0,0);
	box2d.setFPS(30.0);
	ofSetFrameRate(30);
	for(int i = 0; i < 300; i++) {
		addParticle(ofRandomWidth(), ofRandomHeight());
	}
	
	hysteresis = 3;
	nearThreshold = 100;
	farThreshold = 200;
	
	learnBackground = false;
	gui.addContent("depth", depth);
	gui.addSlider("near threshold", nearThreshold, 0, 255);
	gui.addSlider("far threshold", farThreshold, 0, 255);
	gui.addSlider("hysteresis", hysteresis, 0, 20);
	gui.addToggle("learnBackground", learnBackground);
	
	gui.loadFromXML();
	gui.setAutoSave(true);
	ofEnableAlphaBlending();
	
}

//--------------------------------------------------------------
void testApp::update(){

	for(int i = 0; i < particles.size(); i++) {
		particles[i].addAttractionPoint(320, 240);
	}
	
	box2d.update();
	kinect.update();
	if(kinect.isFrameNew()) {
		depth.setFromPixels(kinect.getDepthPixels(), 640, 480);
		depth.threshold(100);

		contours.findContours(depth, 10, 400*400, 20, false);
		
		
		
		
		updateBox2d();
	}
	ofSetWindowTitle(ofToString(ofGetFrameRate(), 1));
}


void testApp::updateBox2d() {
	for(int i = 0; i < outlines.size(); i++) {
		outlines[i].destroy();
	}
	outlines.clear();
	for(int i = 0; i < contours.blobs.size(); i++) {
		outlines.push_back(ofxBox2dPolygon());
		vector<ofVec2f> points;
		for(int j = 0; j < contours.blobs[i].pts.size(); j++) {
			points.push_back(ofVec2f(contours.blobs[i].pts[j].x,contours.blobs[i].pts[j].y));
			
		}
		outlines.back().addVertexes(points);
		outlines.back().simplify();
		outlines.back().triangulate();
		outlines.back().create(box2d.getWorld());
	}
}

//--------------------------------------------------------------
void testApp::draw(){
	ofEnableBlendMode(OF_BLENDMODE_ALPHA);
	glPushMatrix();
	glScalef(ofGetWidth()/640.f, ofGetHeight()/480.f, 1);
	glColor3f(1, 0, 1);
	depth.draw(0, 0);
	
	//flow.draw(0, 0);
	//contours.draw();
	
	ofSetHexColor(0xFFFFFF);
	ofEnableBlendMode(OF_BLENDMODE_ADD);
	for(int i = 0; i < contours.blobs.size(); i++) {
		glBegin(GL_LINE_LOOP);
		for(int j = 0; j < contours.blobs[i].pts.size(); j+=10) {
			glVertex2f(contours.blobs[i].pts[j].x, contours.blobs[i].pts[j].y);
		}
		glEnd();
	}
	for(int i = 0; i < particles.size(); i++) {
		particles[i].draw();
	}
	glPopMatrix();
	
	gui.draw();
}

void testApp::addParticle(float x, float y) {
	particles.push_back(Particle());
	particles.back().init();
	particles.back().setPhysics(10, 0.1, 0.5);
	particles.back().setDamping(0.5);
	particles.back().setup(box2d.getWorld(), x*640.f/(float)ofGetWidth(), y*480.f/(float)ofGetHeight(), 6);

}
//--------------------------------------------------------------
void testApp::keyPressed(int key){
	switch(key) {

		case ' ':
			gui.toggleDraw();
			break;
			
		case 'f':
			ofToggleFullscreen();
			break;
	}
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}


//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

	addParticle(x, y);
	
}


//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

	addParticle(x, y);
	
}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}